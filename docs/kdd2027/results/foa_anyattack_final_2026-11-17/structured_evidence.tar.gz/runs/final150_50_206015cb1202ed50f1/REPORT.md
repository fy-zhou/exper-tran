# Baseline reproduction: PARTIAL / BLOCKED

Split `final150`, eligible N=150, steps=50. Missing evaluations are N/A, never zero ASR. PGD/MI use an explicitly adapted image-only cosine objective. M/FOA use pinned official cores with disclosed task/precision/API adaptations.

See method_lock.json, bf16_proxies.json, attack receipts, optimization traces, evaluation_blockers.json and results.csv. Formal test scores require all planned images; smoke/pilot results are not final results. No commercial calls are made.
